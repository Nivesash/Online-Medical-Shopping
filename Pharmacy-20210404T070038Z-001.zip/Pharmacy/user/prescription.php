<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.file-upload input[type='file'] {
  display: none;
}
body {
  background: #00B4DB;
  background: -webkit-linear-gradient(to right, #0083B0, #00B4DB);
  background: linear-gradient(to right, #0083B0, #00B4DB);
  height: 100vh;
}

.rounded-lg {
  border-radius: 1rem;
}

.custom-file-label.rounded-pill {
  border-radius: 50rem;
}

.custom-file-label.rounded-pill::after {
  border-radius: 0 50rem 50rem 0;
}
</style>
</head>
<body>
<?php
if(isset($_POST['submit']))
{		
   $dbServer = 'localhost';
$dbUser = 'root';
$dbPassword = '';
$dbName = 'pharmacy';
$conn = mysqli_connect($dbServer, $dbUser, $dbPassword, $dbName);
if (isset($_POST['submit'])){
		$uname = $_POST['uname'];
		$email = $_POST['email'];
		$presc = $_POST['file'];
	//	$cat = strtolower(str_replace(' ','',$category));
//$cat = str_replace(' ','',$category);
		$sql = "INSERT INTO `prescriptionupload`(`name`, `email`, `presc`) VALUES ('$uname','$email','$presc')";
		$res = mysqli_query($conn, $sql);
    if(!$sql)
    {
        echo mysqli_error();
    }
    
    
}	
		}
	?>
    
}
<section>
  <div class="container p-5">
    <!-- For demo purpose -->
    <div class="row mb-5 text-center text-white">
      <div class="col-lg-10 mx-auto">
        <h1 class="display-4">prescription upload  </h1>
        <p class="lead">upload prescription for later use.</p>
      </div>
    </div>
    <!-- End -->


    <div class="row">
      <div class="col-lg-5 mx-auto">
        <div class="p-5 bg-white shadow rounded-lg"><img src="https://res.cloudinary.com/mhmd/image/upload/v1557366994/img_epm3iz.png" alt="" width="200" class="d-block mx-auto mb-4 rounded-pill">

          <!-- Default bootstrap file upload-->
<form method="post" action="index.php">
          <h6 class="text-center mb-4 text-muted">
             <div class="form-group">
          <label for="exampleInputEmail1">Email address</label>
          <input type="email" class="form-control" id="exampleInputEmail1" name="email" placeholder="Enter email" required>
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
              <div class="form-group">
          <label for="exampleInputEmail1">NAME:</label>
          <input type="name" class="form-control" id="exampleInputEmail1" name="uname" placeholder="Enter name" required>
        </div>
          </h6>

          <div class="custom-file overflow-hidden rounded-pill mb-5">
            <input id="customFile" name="file" type="file" class="custom-file-input rounded-pill">
            <label for="customFile" class="custom-file-label rounded-pill">Choose file</label>
          </div>
          <!-- End -->
             <input type="submit" value="Submit" name="submit">
    
</form>
        </div>
      </div>
    </div>
  </div>
    

</section>
    
    </form>
</body>
</html>

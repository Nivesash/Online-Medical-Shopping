<?php

include_once '../includes/db.inc.php';

if (isset($_GET['delete'])) {
	$id = $_GET['delete'];
	$sql = "delete from cart where id='$id'";
	mysqli_query($conn, $sql);
	header("Location: ../viewcart.php");
}
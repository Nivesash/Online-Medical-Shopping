<?php

include_once '../includes/db.inc.php';

if (isset($_GET['incr'])) {
	$id = $_GET['incr'];
	$sql = "select * from cart where id='$id'";
	$res = mysqli_query($conn, $sql);
	$rescheck = mysqli_num_rows($res);
	if ($rescheck > 0) {
		while ($row = mysqli_fetch_assoc($res)) {
			$qty = $row['quantity'];
			$qty = $qty + 1;
			$sqlone = "update cart set quantity='$qty' where id='$id';";
			mysqli_query($conn, $sqlone);
			 header("Location: ../viewcart.php");
		}
	}
	
}


if (isset($_GET['dcr'])) {
	$id = $_GET['dcr'];
	$sql = "select * from cart where id='$id'";
	$res = mysqli_query($conn, $sql);
	$rescheck = mysqli_num_rows($res);
	if ($rescheck > 0) {
		while ($row = mysqli_fetch_assoc($res)) {
			$qty = $row['quantity'];
			$qty = $qty - 1;
			$sqlone = "update cart set quantity='$qty' where id='$id';";
			mysqli_query($conn, $sqlone);
			 header("Location: ../viewcart.php");
		}
	}
	
}
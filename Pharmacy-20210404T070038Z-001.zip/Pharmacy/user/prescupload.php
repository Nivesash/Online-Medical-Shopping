<?php
$dbServer = 'localhost';
$dbUser = 'root';
$dbPassword = '';
$dbName = 'pharmacy';
$conn = mysqli_connect($dbServer, $dbUser, $dbPassword, $dbName);
if (!empty($_POST)) {
		$uname = $_POST['uname'];
		$email = $_POST['email'];
		$presc = $_POST['file'];
	//	$cat = strtolower(str_replace(' ','',$category));
//$cat = str_replace(' ','',$category);
		$sql = "INSERT INTO `prescriptionupload`(`name`, `email`, `presc`) VALUES ($uname,$email,$presc)";
		$res = mysqli_query($conn, $sql);
		if (!$res) {
			header("Location: ../prescrition.php?result=fail");
		} else {
			?>
			<script type="text/javascript">
				alert("Item Added Successfully!!");
				header("Location: ../prescrition.php);
			</script>
		
		}
	}

?>

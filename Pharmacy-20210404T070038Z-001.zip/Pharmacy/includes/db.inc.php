<?php
$dbServer = 'localhost';
$dbUser = 'root';
$dbPassword ='';
$dbName = 'pharmacy';
$conn = mysqli_connect($dbServer, $dbUser, $dbPassword,$dbName);
?>